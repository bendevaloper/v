<?php


namespace App\Services\AutoResponder;


class AutoResponderServiceInterface
{

}
