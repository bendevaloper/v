<?php

namespace App\Services;
interface SmsManagerServiceInterface
{

}
