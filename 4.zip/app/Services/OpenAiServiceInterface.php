<?php

namespace App\Services;
interface OpenAiServiceInterface
{

}
