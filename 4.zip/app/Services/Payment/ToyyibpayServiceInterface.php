<?php

namespace App\Services\Payment;
interface ToyyibpayServiceInterface
{

}
