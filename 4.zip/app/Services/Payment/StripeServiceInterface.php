<?php

namespace App\Services\Payment;
interface StripeServiceInterface
{

}
