<?php

namespace App\Services\Payment;
interface PaypalServiceInterface
{

}
