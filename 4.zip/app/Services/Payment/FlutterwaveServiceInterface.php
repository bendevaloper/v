<?php

namespace App\Services\Payment;
interface FlutterwaveServiceInterface
{

}