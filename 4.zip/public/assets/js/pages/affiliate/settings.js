"user strict";
  $(document).ready(function($) {
        setTimeout(function(){
            $("#gif_div").hide(500);
            $("#link_div").show(500);
        },1000);
    });