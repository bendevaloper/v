"use strict";
window.addEventListener('load', function () {
$(".preloading_body").fadeOut("slow");
}, false);