"use strict";

$(document).ready(function() {

	$('#summernote').summernote();

});